# NewLisp 并发端口扫描器任务文档

## 背景
- 需要一个使用友好、参数通俗易懂的端口扫描工具。
- 使用 newLISP 编写，支持并发扫描，提高效率。
- 支持多种参数传入方式：命令行参数、目标/端口列表文件、配置文件。
- 结果可与其他三方工具衔接，尤其是 nmap（生成可直接执行的命令或可作为输入的文件）。

## 目标
- 提供一个跨平台（Unix/Linux 优先）的 TCP 端口扫描器 `nlscan.lsp`。
- 实现并发扫描能力（进程并发，用户可配置并发度）。
- 提供超时控制，避免长时间阻塞。
- 支持多种输入/输出：
  - 目标：逗号分隔、`@file` 文件、IPv4 CIDR（如 `192.168.1.0/24`）、域名/IP。
  - 端口：逗号分隔与区间（如 `80,443,22-25`）。
  - 输出：text、json、ndjson；可指定输出文件。
  - 配置文件：INI 风格 `key=value`（注释以 `#` 开头）。
- 提供 nmap 衔接：
  - 生成每个目标的 nmap 命令（含开放端口），保存为 shell 脚本。
  - 生成 `-iL` 目标文件（仅包含存在开放端口的目标）。

## 非功能性要求
- 并发：默认 200，可通过 `--concurrency` 调整。
- 超时：默认 1 秒，通过 `--timeout` 调整。
- 可靠性：对无效输入、权限不足、不可达网络等情况给出清晰提示；返回码合理（执行成功返回 0）。
- 可移植性：尽量只依赖系统常见工具（使用 `nc` 进行连接检测）。

## 交互与参数规范（CLI）
- `--targets, -t`：目标，支持：
  - 逗号分隔列表：`-t 192.168.1.10,example.com`，
  - 文件：`-t @targets.txt`（每行一个目标，支持空行与 `#` 注释），
  - CIDR：`-t 192.168.1.0/28`（仅 IPv4）。
- `--ports, -p`：端口，支持逗号和区间：`-p 22,80,443,8000-8100`。
- `--concurrency, -c`：并发 worker 数，默认 200。
- `--timeout, -T`：每个端口连接超时（秒，整数），默认 1。
- `--format, -f`：输出格式：`text|json|ndjson`，默认 `text`。
- `--output, -o`：输出文件路径；不指定则输出到 stdout。
- `--config, -C`：从配置文件加载（INI 风格）。命令行参数会覆盖配置文件中的同名项。
- `--emit-nmap-cmds PATH`：将每个目标的 nmap 命令写入到 `PATH`。
- `--emit-nmap-iL PATH`：将有开放端口的目标列表写到 `PATH`（可用于 `nmap -iL PATH`）。
- `--method`：`nc` 或 `net`，默认 `nc`；`net` 为 newLISP `net-connect`，但不保证精确超时，推荐 `nc`。
- `--help, -h`：打印帮助。

## 设计概述
- 任务展开为 (目标 × 端口) 的组合列表，然后按并发度 N 划分为 N 份，由 N 个 worker 子进程并行执行。
- 每个 worker 使用 `nc -z -w <timeout> host port` 进行 TCP 连接探测，结果写入 worker 专属临时文件。
- 主进程等待所有 worker 完成，汇总结果并按 `--format` 输出；若设置 `--emit-*`，生成 nmap 衔接文件。
- 若选择 `--method net`，则用 `(net-connect host port)` 判断，但无法提供精确的连接超时（仅用于无 `nc` 环境的兜底）。

## 测试计划
1. 本地起一个临时 HTTP 服务（Python http.server）在端口 `9999`。
2. 使用 `--targets 127.0.0.1 --ports 9999,65535 --concurrency 4 --timeout 1` 运行扫描：
   - 期望 `9999` 为 open，`65535` 为 closed。
   - 同时验证 `--format json` 与 `--format ndjson` 输出。
3. 测试配置文件：创建 INI 配置，使用 `--config` 运行，验证输出一致。
4. 测试 `--emit-nmap-cmds` 与 `--emit-nmap-iL` 产物文件格式。

## 交付物
- 源码：`tools/nlscan.lsp`
- 文档：本任务文档 `docs/TASK.md` 与使用说明 `README.md`
- 测试：`tests/run.sh`

## 验收标准
- 所有测试脚本 `tests/run.sh` 全部通过且退出码为 0。
- 工具支持文档所述所有参数，并能正常输出结果与 nmap 衔接文件。

